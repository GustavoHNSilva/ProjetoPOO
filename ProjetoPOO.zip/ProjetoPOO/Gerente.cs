public class Gerente : Funcionario
{
    public Gerente(string nome) : base(nome, "Gerente") {}

    public override double CalcularCustoHora()
    {
        return 150.0; // valor fixo só como exemplo
    }
}

public class Gerente : Funcionario
{
    public Gerente(string nome) : base(nome)
    {
        Cargo = "Gerente";
    }

    public override double CalcularCustoHora() => 150.0;
}
